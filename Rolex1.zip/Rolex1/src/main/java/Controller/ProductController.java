package Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ProductController {
	@RequestMapping("/product")
	public String goproduct(){
		return "product";
	}
	
	@RequestMapping("/viewproduct")
	public String goviewproduct(){
		return "viewproduct";
	}
	
	@RequestMapping("/editproduct")
	public String goeditproduct(){
		return "editproduct";
	}
	@RequestMapping("/deleteproduct")
	public String godeleteproduct(){
		return "deleteproduct";
	}
}
