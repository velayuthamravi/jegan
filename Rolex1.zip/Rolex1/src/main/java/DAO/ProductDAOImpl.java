package DAO;

import java.util.List;

import Model.ProductModel;

public class ProductDAOImpl implements ProductDAO {

	public void addProduct(ProductModel p) {
		// TODO Auto-generated method stub
		
	}

	public void viewProduct(String code) {
		// TODO Auto-generated method stub
		
	}

	public void deleteProduct(ProductModel p) {
		// TODO Auto-generated method stub
		
	}

	public void editProduct(ProductModel p) {
		// TODO Auto-generated method stub
		
	}

	public List<ProductModel> ViewProductModel() {
		// TODO Auto-generated method stub
		return null;
	}

	public ProductModel viewProductby(String code) {
		// TODO Auto-generated method stub
		return null;
	}

}
