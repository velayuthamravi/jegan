package DAO;


import java.util.List;

import Model.SupplierModel;

public class SupplierDAOImpl implements SupplierDAO {

	public void addSupplier(SupplierModel p) {
		// TODO Auto-generated method stub
		
	}

	public void viewSupplier(String code) {
		// TODO Auto-generated method stub
		
	}

	public void deleteSupplier(SupplierModel p) {
		// TODO Auto-generated method stub
		
	}

	public void editSupplier(SupplierModel p) {
		// TODO Auto-generated method stub
		
	}

	public List<SupplierModel> ViewSupplierModel() {
		// TODO Auto-generated method stub
		return null;
	}

	public SupplierModel viewSupplierby(String code) {
		// TODO Auto-generated method stub
		return null;
	}

}
