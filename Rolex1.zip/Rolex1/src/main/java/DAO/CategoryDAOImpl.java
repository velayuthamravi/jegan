package DAO;

import java.util.List;

import Model.CategoryModel;

public class CategoryDAOImpl implements CategoryDAO {

	public void addCategory(CategoryModel p) {
		// TODO Auto-generated method stub
		
	}

	public void viewCategory(String code) {
		// TODO Auto-generated method stub
		
	}

	public void deleteCategory(CategoryModel p) {
		// TODO Auto-generated method stub
		
	}

	public void editCategory(CategoryModel p) {
		// TODO Auto-generated method stub
		
	}

	public List<CategoryModel> ViewCategoryModel() {
		// TODO Auto-generated method stub
		return null;
	}

	public CategoryModel viewCategoryby(String code) {
		// TODO Auto-generated method stub
		return null;
	}

}
